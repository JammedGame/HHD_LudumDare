<?xml version="1.0" encoding="UTF-8"?>
<tileset name="main" tilewidth="102" tileheight="102" tilecount="22" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="100" height="100" source="../../../../../../../Downloads/zid_08.png"/>
 </tile>
 <tile id="2">
  <image width="100" height="99" source="../../../../../../../Desktop/tiles/ZID 1.png"/>
 </tile>
 <tile id="3">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/ZID 2.png"/>
 </tile>
 <tile id="4">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_prav1.png"/>
 </tile>
 <tile id="5">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_vertical.png"/>
 </tile>
 <tile id="6">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_angle_1.png"/>
 </tile>
 <tile id="7">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_ugao1.png"/>
 </tile>
 <tile id="8">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_angle_3.png"/>
 </tile>
 <tile id="9">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/pipe_angle_2.png"/>
 </tile>
 <tile id="10">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/masina.png"/>
 </tile>
 <tile id="11">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/barrel barell.png"/>
 </tile>
 <tile id="12">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/plinska bocaaa.png"/>
 </tile>
 <tile id="13">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/vatra.png"/>
 </tile>
 <tile id="14">
  <image width="94" height="100" source="../../../../../../../Desktop/tiles/Untitled-1.png"/>
 </tile>
 <tile id="15">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/nova kutija.png"/>
 </tile>
 <tile id="16">
  <image width="101" height="100" source="../../../../../../../Desktop/tiles/ventilator 1.png"/>
 </tile>
 <tile id="17">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/heat.png"/>
 </tile>
 <tile id="18">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/vrata.png"/>
 </tile>
 <tile id="19">
  <image width="102" height="102" source="../../../../../../../Downloads/poluga_up.png"/>
 </tile>
 <tile id="20">
  <image width="100" height="100" source="../../../../../../../Desktop/tiles/dugme 2 gore.png"/>
 </tile>
 <tile id="21">
  <image width="100" height="100" source="../../../../../../../Downloads/zid_04.png"/>
 </tile>
 <tile id="22">
  <image width="100" height="100" source="../../../../../../../Downloads/zid_01.png"/>
 </tile>
</tileset>
