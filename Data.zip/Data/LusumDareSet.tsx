<?xml version="1.0" encoding="UTF-8"?>
<tileset name="LudumDareSet" tilewidth="101" tileheight="101" tilecount="23" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="100" height="100" source="Sprites/zid_08.png"/>
 </tile>
 <tile id="1">
  <image width="100" height="100" source="Sprites/ZID 2.png"/>
 </tile>
 <tile id="2">
  <image width="100" height="100" source="Sprites/ZID 2.png"/>
 </tile>
 <tile id="3">
  <image width="100" height="100" source="Sprites/pipe_prav1.png"/>
 </tile>
 <tile id="4">
  <image width="100" height="100" source="Sprites/pipe_prav2.png"/>
 </tile>
 <tile id="5">
  <image width="100" height="100" source="Sprites/pipe_ugao2.png"/>
 </tile>
 <tile id="6">
  <image width="100" height="100" source="Sprites/pipe_ugao1.png"/>
 </tile>
 <tile id="7">
  <image width="100" height="100" source="Sprites/pipe_ugao4.png"/>
 </tile>
 <tile id="8">
  <image width="100" height="100" source="Sprites/pipe_ugao3.png"/>
 </tile>
 <tile id="9">
  <image width="100" height="100" source="Sprites/masina verzija 2.png"/>
 </tile>
 <tile id="10">
  <image width="100" height="100" source="Sprites/barrel barell.png"/>
 </tile>
 <tile id="11">
  <image width="100" height="100" source="Sprites/plinska bocaaa.png"/>
 </tile>
 <tile id="12">
  <image width="100" height="100" source="Sprites/vatra.png"/>
 </tile>
 <tile id="13">
  <image width="94" height="100" source="Sprites/Untitled-1.png"/>
 </tile>
 <tile id="14">
  <image width="100" height="101" source="Sprites/KUTIJA NOVOOO.png"/>
 </tile>
 <tile id="15">
  <image width="101" height="100" source="Sprites/ventilator 3.png"/>
 </tile>
 <tile id="16">
  <image width="100" height="100" source="Sprites/heat.png"/>
 </tile>
 <tile id="17">
  <image width="100" height="100" source="Sprites/vrata verzija 5.png"/>
 </tile>
 <tile id="18">
  <image width="100" height="96" source="Sprites/poluga_up.png"/>
 </tile>
 <tile id="19">
  <image width="100" height="100" source="Sprites/dugme gore.png"/>
 </tile>
 <tile id="20">
  <image width="100" height="100" source="Sprites/zid_04.png"/>
 </tile>
 <tile id="21">
  <image width="100" height="100" source="Sprites/zid_01.png"/>
 </tile>
 <tile id="22">
  <image width="100" height="100" source="Sprites/zid_01 copy.png"/>
 </tile>
</tileset>
